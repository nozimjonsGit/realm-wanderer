* [About the Multiplayer Center package](index.md)
* [System requirements](sys-req)
* [Use the Multiplayer Center window](use-multiplayer-center)
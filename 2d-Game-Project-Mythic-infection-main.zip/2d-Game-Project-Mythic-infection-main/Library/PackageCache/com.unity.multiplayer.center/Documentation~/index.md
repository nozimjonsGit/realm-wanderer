# Multiplayer Center package

The Multiplayer Center package generates a customized list of Unity packages and services for the type of multiplayer game you want to create and installs them.

## Install 

To install this package, refer to [Install a package from a registry](https://docs.unity3d.com/Manual/upm-ui-install.html).

# Unity UI
The Unity UI package allows you to create in-game user interfaces fast and intuitively.

## Prerequisites
### Unity 2019.2
This package is in development, and requires Unity 2019.2.

## Getting Started
The Unity UI user manual can be found [here](https://docs.unity3d.com/Manual/UISystem.html).

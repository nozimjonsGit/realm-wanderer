# Supported Rich Text Tags

The following table is a quick reference of supported rich text tags. For details, see the main pages for specific tags.

[!include[](include-rich-text-tags.md)]
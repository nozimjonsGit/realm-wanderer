# Changelog

## [2.0.0] - 2023-03-08
Merge of the com.unity.textmeshpro package.

## [1.0.0] - 2019-01-08
This is the first release of Unity UI as a built in package.
